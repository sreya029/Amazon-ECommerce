SELECT 
    a.`Product Category`, 
    a.TotalSales AS CurrentYearSales,
    b.TotalSales AS PreviousYearSales,
    (a.TotalSales - b.TotalSales) AS SalesIncrease
FROM
    (SELECT `Product Category`, SUM(`Sale Price`) AS TotalSales
     FROM orders
     WHERE YEAR(OrderDate) = 2020
     GROUP BY `Product Category`) AS a
JOIN
    (SELECT `Product Category`, SUM(`Sale Price`) AS TotalSales
     FROM orders
     WHERE YEAR(OrderDate) = 2019
     GROUP BY `Product Category`) AS b
ON a.`Product Category` = b.`Product Category`
ORDER BY SalesIncrease DESC
LIMIT 3;
