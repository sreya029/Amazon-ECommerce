SELECT
    `Product Category`,
    EXTRACT(YEAR FROM OrderDate) AS year,
    EXTRACT(MONTH FROM OrderDate) AS month,
    SUM(`Sale Price`) AS total_revenue,
    AVG(SUM(`Sale Price`)) OVER (
        PARTITION BY `Product Category`
        ORDER BY EXTRACT(YEAR FROM OrderDate), EXTRACT(MONTH FROM OrderDate)
        ROWS BETWEEN 2 PRECEDING AND CURRENT ROW
    ) AS rolling_3_month_avg_revenue
FROM orders
GROUP BY
    `Product Category`,
    EXTRACT(YEAR FROM OrderDate),
    EXTRACT(MONTH FROM OrderDate)
ORDER BY
    `Product Category`,
    year,
    month;

