SELECT
  year,
  month,
  total_revenue,
  ((total_revenue - LAG(total_revenue) OVER (ORDER BY year, month)) 
    / LAG(total_revenue) OVER (ORDER BY year, month)) * 100 AS mom_growth_percentage
FROM (
  SELECT
    EXTRACT(YEAR FROM OrderDate) AS year,
    EXTRACT(MONTH FROM OrderDate) AS month,
    SUM(`Sale Price`) AS total_revenue
  FROM orders
  GROUP BY year, month
) AS monthly;

