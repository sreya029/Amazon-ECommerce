WITH OrderDiffs AS (
    SELECT
        CustomerID,
        OrderDate,
        LEAD(OrderDate) OVER (PARTITION BY CustomerID ORDER BY OrderDate) AS next_order_date
    FROM orders
),
QualifiedDiffs AS (
    SELECT
        CustomerID,
        DATEDIFF(next_order_date, OrderDate) AS days_between
    FROM OrderDiffs
    WHERE next_order_date IS NOT NULL
    
),
QualifiedCustomers AS (
    SELECT CustomerID
    FROM orders
    GROUP BY CustomerID
    HAVING COUNT(OrderID) >= 5
)
SELECT 
    AVG(days_between) AS avg_days_between_orders
FROM QualifiedDiffs
WHERE CustomerID IN (SELECT CustomerID FROM QualifiedCustomers)
group by CustomerID;
