WITH CustomerRevenue AS (
    SELECT
        CustomerID,
        SUM(`Sale Price`) AS total_revenue
    FROM orders
    GROUP BY CustomerID
),
AverageRevenue AS (
    SELECT
        AVG(total_revenue) AS avg_revenue
    FROM CustomerRevenue
)
SELECT
    cr.CustomerID,
    cr.total_revenue
FROM CustomerRevenue cr
JOIN AverageRevenue ar
    ON cr.total_revenue > ar.avg_revenue * 1.3;
