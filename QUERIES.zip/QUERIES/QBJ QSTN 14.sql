WITH CustomerMetrics AS (
    SELECT c.CustomerID,
    SUM(o.`Sale Price`) OVER (PARTITION BY c.CustomerID) AS TotalRevenue,
	COUNT(o.OrderID) OVER (PARTITION BY c.CustomerID) AS OrderFrequency,
	AVG(o.`Sale Price`) OVER (PARTITION BY c.CustomerID) AS AverageOrderValue
    FROM customers c
    JOIN orders o ON c.CustomerID = o.CustomerID
)
SELECT DISTINCT CustomerID,
	TotalRevenue,
	OrderFrequency,
    AverageOrderValue,
	(TotalRevenue * 0.5 + OrderFrequency * 0.3 + AverageOrderValue * 0.2) AS CompositeScore
FROM CustomerMetrics
ORDER BY CompositeScore DESC
LIMIT 5; 